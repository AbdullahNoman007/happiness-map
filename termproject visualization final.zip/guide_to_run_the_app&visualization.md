## World happiness report "shiny" application 

 
I will provide an .Rmd file, of this app as well as the datasets and source codes required to run this application. 



The shiny app can be initialized in two ways.

**Important** In each case, the directories have to be changed based on where the datasets have been downloaded.

1)Simply copy the entire codes from the "source_code_for_application.md" readme file and copy them in an Rconsole or Rscript. 
Then change the directories as per where the datasets have been downloaded and run.  
                    
                                                                     Or,

2)Double Click the happinessApplication.Rmd file. Change the directories as per where the datasets have been downloaded. Then click Run Document. 
A message may show up saying that there are shiny inputs inside the file. The user has to click "Yes Always". Then the app will show up.





## World happiness report "plotly" visualization


The plotly visualization can be initialized in two ways.

**Important** In each case, the directories have to be changed based on where the datasets have been downloaded. 

1)Simply copy the entire codes from the "source_code_for_visualization.md" readme file and copy them in an Rconsole or Rscript. 
Then change the directories as per where the datasets have been downloaded and run.
 
                                                                       Or,


2)Double click on the happinessplotly2.Rmd file. Change the directories as per where the datasets have been downloaded.
Click knit/knit to html, and the visualization will appear.