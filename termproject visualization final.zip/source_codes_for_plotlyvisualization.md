##Source code for plotly visualization. The visualization can be initiated just by copying the entire codes into an Rconsole or Rscript. The directories of the datasets have 
to be changed.

install.packages("readxl")
install.packages("tidyverse")
install.packages("plotly")
install.packages("extrafont")
library(readxl)
library(tidyverse)
library(plotly)
library(extrafont)

data15<- read.csv("C:\\Users\\Arde\\OneDrive\\Desktop\\happinessdata\\2015.csv")

data16<- read.csv("C:\\Users\\Arde\\OneDrive\\Desktop\\happinessdata\\2016.csv")

data17<- read.csv("C:\\Users\\Arde\\OneDrive\\Desktop\\happinessdata\\2017.csv")

data18<- read.csv("C:\\Users\\Arde\\OneDrive\\Desktop\\happinessdata\\2018.csv")

data19<- read.csv("C:\\Users\\Arde\\OneDrive\\Desktop\\happinessdata\\2019.csv")

data20<- read.csv("C:\\Users\\Arde\\OneDrive\\Desktop\\happinessdata\\happiness2020.csv")

data21<- read.csv("C:\\Users\\Arde\\OneDrive\\Desktop\\happinessdata\\happiness.csv")

iso_codes<- read_excel("C:\\Users\\ARDE\\OneDrive\\Desktop\\Book1.xlsx")



happiness21<- data21%>%select(ï..Country.name, Ladder.score)

happiness21["Happiness.Score15"]<- data15$Happiness.Score[match(happiness21$ï..Country.name, data15$Country)]

happiness21["Happiness.Score16"]<- data16$Happiness.Score[match(happiness21$ï..Country.name, data16$Country)]

happiness21["Happiness.Score17"]<- data17$Happiness.Score[match(happiness21$ï..Country.name, data17$Country)]

happiness21["Happiness.Score18"]<- data18$Score[match(happiness21$ï..Country.name, data18$Country.or.region)]

happiness21["Happiness.Score19"]<- data19$Score[match(happiness21$ï..Country.name, data19$Country.or.region)]

happiness21["Happiness.Score20"]<- data20$Ladder.score[match(happiness21$ï..Country.name, data20$Country.name)]

colnames(happiness21)<- c("Country", "2021", "2015","2016","2017","2018","2019","2020")



oldnamess<- c("United States", "Taiwan Province of China", "Kosovo", "South Korea", "Russia", "North Cyprus", "Hong Kong S.A.R of China", "Vietnam", "Ivory Coast", "Congo (Brazzaville)", "Macedonia", "Venezueala", "Laos", "Iran", "Palestinian Territories", "Congo (Kinshasa)", "Tanzania")

newnamess<- c("United States of America","Taiwan, Republic of China", "Korea (South)", "Cyprus", "Russian Federation", "Hong Kong, SAR China","Viet Nam","Congo (Brazzaville)", "Côte d'Ivoire", "Macedonia, Republic of", "Lao PDR", "Venezuela (Bolivarian Republic)","Iran, Islamic Republic of", "Palestinian Territory", "Tanzania, United Republic of" )

for (i in 1:length(oldnamess)){
               happiness21$Country[happiness21$Country == oldnamess[i]] <- newnamess[i]
}

happiness21['ISO3'] <- iso_codes$ISO3[match(happiness21$Country, iso_codes$Country)]

test<- happiness21[is.na(happiness21$ISO3),]

View(test)

happiness_na_deleted<- happiness21[-c(33,78,95,108,143),]

happinesstable<- gather(happiness_na_deleted, key = "Year", value = "Value", `2015`,`2016`, `2017`,`2020`, `2018`, `2019`, `2021`)

happinesstable1<- happinesstable%>%mutate(hover=paste0(Country,"\n", Value))

fontstyle=list(family="DM Sans", size=15, color="black")

label=list(bgcolor="#EEEEEE", bordercolor="transparent", font=fontstyle)

happiness_graph<- plot_geo(happinesstable1, locationmode='world', frame=~Year)%>%add_trace(locations=~ISO3, z=~Value, zmin=0, zmax=max(happinesstable1$Value), color=~Value, colorscale='Electric', text=~hover, hoverinfo='text')%>%layout(geo=list(scope='world'), font=list(family="DM Sans"), title="World Happiness Score 2015-2021",height=600, width=950)%>%style(hoverlabel=label)

happiness_graph