

##The application can be run just by copying the following codes in an R console/ Rscript. The following packages have to be installed first by using install.packages("") command. shiny may require an updated version of htmltools. 
It can be updated by going to Tools → check for package updates → select htmltools → install updates.


install.packages("rvest")
install.packages("readxl")
install.packages("ggplot2")
install.packages("tidyverse")
install.packages("maps")
install.packages("reshape2")
install.packages("htmltools")
install.packages("shiny")
install.packages("ggiraph")
library(ggiraph)
library(rvest)
library(readxl)
library(ggplot2)
library(tidyverse)
library(maps)
library(reshape2)
library(htmltools)
library(shiny)


##Loading the databases from my desktop. (Change the directory as per where the data was downloaded)

iso_codes<- read_excel("C:\\Users\\ARDE\\OneDrive\\Desktop\\Book1.xlsx")
world_data <- ggplot2::map_data('world')
world_data <- fortify(world_data)
happiness<- read.csv("C:\\Users\\ARDE\\OneDrive\\Desktop\\happiness.csv")
happiness2020<- read.csv("C:\\Users\\ARDE\\OneDrive\\Desktop\\happiness2020.csv")


##setting the ISO3 column on happiness dataset 2021. We will see which countries don't get ISO3's and change their names according to their names on the iso_codes dataset.

happiness['ISO3'] <- iso_codes$ISO3[match(happiness$ï..Country.name, iso_codes$Country)]
test_2<- happiness[is.na(happiness$ISO3),]
oldnamess<- c("United States", "Taiwan Province of China", "Kosovo", "South Korea", "Russia", "North Cyprus", "Hong Kong S.A.R of China", "Vietnam", "Ivory Coast", "Congo (Brazzaville)", "Macedonia", "Venezueala", "Laos", "Iran", "Palestinian Territories", "Congo (Kinshasa)", "Tanzania")

newnamess<- c("United States of America","Taiwan, Republic of China", "Korea (South)", "Cyprus", "Russian Federation", "Hong Kong, SAR China","Viet Nam","Congo (Brazzaville)", "Côte d'Ivoire", "Macedonia, Republic of", "Lao PDR", "Venezuela (Bolivarian Republic)","Iran, Islamic Republic of", "Palestinian Territory", "Tanzania, United Republic of" )


for (i in 1:length(oldnamess)){
                    happiness$ï..Country.name[happiness$ï..Country.name == oldnamess[i]] <- newnamess[i]
                }

happiness['ISO3'] <- iso_codes$ISO3[match(happiness$ï..Country.name, iso_codes$Country)]



##we will see that countries of the rows 33, 95, 108 and 143 still don’t have ISO3. We will simply remove this rows to avoid NA values.

happiness<- happiness[-c(33,95,108,143),]


##now we will select only the columns we need from the happiness database and create a new database named happiness1 which will contain the columns we need. We will rename the columns as well. 

happiness1<- happiness%>%select(ï..Country.name, Ladder.score, Logged.GDP.per.capita, Social.support,Healthy.life.expectancy,Freedom.to.make.life.choices,Generosity,Perceptions.of.corruption,ISO3 )
colnames(happiness1)<-c("Country Name", "Ladder Score","Logged GDP per Capita","Social Support","Healthy Life Expectancy","Freedom to Make Life Choices", "Generosity", "Perception of Corruption","ISO3")
year2021<- gather(happiness1, key = "Happiness Metric", value = "Value",`Ladder Score`, `Logged GDP per Capita`, `Social Support`,`Healthy Life Expectancy`, `Freedom to Make Life Choices`, Generosity, `Perception of Corruption`)



##We will set the ISO3 column on the world_data database from the ISO3 database. From the following codes, we will see which countries from the world_data database don’t have ISO3. We have to set those countries’ name according to their name on the iso_codes dataset. The world_data database is retrieved from maps package.

world_data["ISO3"] <- iso_codes$ISO3[match(world_data$region, iso_codes$Country)]
test_1<- world_data[is.na(world_data$ISO3),]
old_names <- c("French Southern and Antarctic Lands", "Antigua", "Barbuda", "Saint Barthelemy", "Brunei", "Ivory Coast",
                                "Democratic Republic of the Congo", "Republic of Congo", "Falkland Islands", "Micronesia", "UK", 
                                "Heard Island", "Cocos Islands", "Iran", "Nevis", "Saint Kitts", "South Korea", "Laos", "Saint Martin",
                                "Macedonia", "Pitcairn Islands", "North Korea", "Palestine", "Russia", "South Sandwich Islands",
                                "South Georgia", "Syria", "Trinidad", "Tobago", "Taiwan", "Tanzania", "USA", "Vatican", "Grenadines",
                                "Saint Vincent", "Venezuela", "Vietnam", "Wallis and Fortuna")


new_names <- c("French Southern Territories", rep("Antigua and Barbuda", 2), "Saint-Barthélemy",
                                "Brunei Darussalam", "Côte d'Ivoire", "Congo, (Kinshasa)", "Congo (Brazzaville)", 
                                "Falkland Islands (Malvinas)", "Micronesia, Federated States of", "United Kingdom",
                                "Heard and Mcdonald Islands", "Cocos (Keeling) Islands", "Iran, Islamic Republic of",
                                rep("Saint Kitts and Nevis", 2), "Korea (South)", "Lao PDR", "Saint-Martin (French part)",
                                "Macedonia, Republic of", "Pitcairn", "Korea (North)", "Palestinian Territory", "Russian Federation",
                                rep("South Georgia and the South Sandwich Islands", 2), 
                                "Syrian Arab Republic (Syria)", rep("Trinidad and Tobago", 2), "Taiwan, Republic of China",
                                "Tanzania, United Republic of", "United States of America", "Holy See (Vatican City State)",
                                rep("Saint Vincent and Grenadines", 2), "Venezuela (Bolivarian Republic)", "Viet Nam", "Wallis and Futuna Islands")


for (i in 1:length(old_names)){
          world_data$region[world_data$region == old_names[i]] <- new_names[i]
      }


world_data["ISO3"] <- iso_codes$ISO3[match(world_data$region, iso_codes$Country)]





##now we will set the ISO3 column on the happiness 2020 dataset and follow the same steps. 


happiness2020['ISO3'] <- iso_codes$ISO3[match(happiness2020$Country.name, iso_codes$Country)]
test_3<- happiness2020[is.na(happiness$ISO3),]
oldnam<- c("United States","Taiwan Province of China", "South Korea","Russia", "North Cypurs", "Hong Kong S.A.R. of China", "Vietnam","Ivory Coast", "Congo (Brazzaville)","Macedonia","Venezuela", "Laos", "Iran", "Palestinian Territories", "Congo (Kinshasa)", "Tanzania")
newnam<-c("United States of America", "Taiwan, Republic of China","Korea (South)","Russian Federation", "Cyprus", "Hong Kong, SAR China", "Viet Nam", "Côte d'Ivoire", "Congo (Brazzaville)", "Macedonia, Republic of","Venezuela (Bolivarian Republic)","Lao PDR","Iran, Islamic Republic of","Palestinian Territory", "Congo, (Kinshasa)", "Tanzania, United Republic of")
for (i in 1:length(oldnam)){
                         happiness2020$Country.name[happiness2020$Country.name == oldnam[i]] <- newnam[i]
                     }
happiness2020['ISO3'] <- iso_codes$ISO3[match(happiness2020$Country.name, iso_codes$Country)]
happiness2020<- happiness2020[-c(35,61,77,89,100),]
happiness2020<- happiness2020%>% select(Country.name, Ladder.score,Logged.GDP.per.capita, Social.support,Healthy.life.expectancy, Freedom.to.make.life.choices, Generosity, Perceptions.of.corruption, ISO3)
colnames(happiness2020)<-c("Country Name", "Ladder Score","Logged GDP per Capita","Social Support","Healthy Life Expectancy","Freedom to Make Life Choices", "Generosity", "Perception of Corruption","ISO3")
year2020<- gather(happiness2020, key = "Happiness Metric", value = "Value",`Ladder Score`,`Logged GDP per Capita`, `Social Support`,`Healthy Life Expectancy`, `Freedom to Make Life Choices`, Generosity, `Perception of Corruption`)



##now we will bind the two datasets (year2020 and year2021) together


year2020["DataType"] <- rep("Year 2020", nrow(year2020))
year2021["DataType"] <- rep("Year 2021", nrow(year2021))
df <- rbind(year2020, year2021)
df[] <- lapply(df, as.character)
df$Value <- as.numeric(df$Value)


## Setting up the world map



 worldMaps <- function(df, world_data, data_type, happinessmetric){
    my_theme <- function () { 
         theme_bw() + theme(axis.title = element_blank(),
                            axis.text = element_blank(),
                            axis.ticks = element_blank(),
                            panel.grid.major = element_blank(), 
                            panel.grid.minor = element_blank(),
                            panel.background = element_blank(), 
                            legend.position = "bottom",
                            panel.border = element_blank(), 
                            strip.background = element_rect(fill = 'white', colour = 'white'))
     }

plotdf <- df[df$`Happiness Metric` == happinessmetric & df$DataType == data_type,]
     plotdf <- plotdf[!is.na(plotdf$ISO3), ]
     
     
     world_data['DataType'] <- rep(data_type, nrow(world_data))
     world_data['Happiness Metric'] <- rep(happinessmetric, nrow(world_data))
     world_data['Value'] <- plotdf$Value[match(world_data$ISO3, plotdf$ISO3)]

capt <- paste0("Source: ", ifelse(data_type == "World Happiness Report" , "World Happiness Report", "World Happiness Report"))

library(RColorBrewer)
library(ggiraph)
g <- ggplot() + 
         geom_polygon_interactive(data = subset(world_data, lat >= -60 & lat <= 90), color = 'gray70', size = 0.1,
                                  aes(x = long, y = lat, fill = Value, group = group, 
                                      tooltip = sprintf("%s<br/>%s", ISO3, Value))) + 
         scale_fill_gradientn(colours = brewer.pal(5, "RdBu"), na.value = 'white') + 
         labs(fill = data_type, color = data_type, title = NULL, x = NULL, y = NULL, caption = capt) + 
         my_theme()
     
     return(g)
 }



##activating shiny



ui = fluidPage(
    
     titlePanel("World Happiness Report"),
     
     sidebarLayout(
          
         sidebarPanel(
             
             
             selectInput(inputId = "data_type",
                         label = "Choose the year you want to see:",
                         choices = list("Year 2020" = "Year 2020", "Year 2021" = "Year 2021")),
             
             
             uiOutput("secondSelection")
             
         ),
         
       
         mainPanel(
             
             
             tags$style(type = "text/css",
                        ".shiny-output-error { visibility: hidden; }",
                        ".shiny-output-error:before { visibility: hidden; }"),
             
    
             girafeOutput("distPlot")
             
         )
     )
 )
 

 server = function(input, output) {
     
   
     output$distPlot <- renderGirafe({
         ggiraph(code = print(worldMaps(df, world_data, input$data_type, input$happinessmetric)))
     })
     

     output$secondSelection <- renderUI({
         choice_second <- as.list(unique(df$`Happiness Metric`[which(df$DataType == input$data_type)]))
        selectInput(inputId = "happinessmetric", choices = choice_second,
                     label = "Choose the variable for which you want to see the data:")
     })
     
    
 }



##opening the app



shinyApp(ui=ui, server = server)



